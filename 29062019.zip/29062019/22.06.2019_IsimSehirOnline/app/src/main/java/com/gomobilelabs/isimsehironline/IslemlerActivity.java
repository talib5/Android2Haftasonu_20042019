package com.gomobilelabs.isimsehironline;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import de.hdodenhof.circleimageview.CircleImageView;

public class IslemlerActivity extends AppCompatActivity {

    ListView listView;
    ArrayAdapter<String> arrayAdapter;
    String[] array = {"Hemen Oyna", "Sohbet", "Mesajlar", "Profilim", "Top 10", "Altın Kazan", "Oyunu Paylaş"};
    TextView tvKullaniciAdSoyad, tvOyunPuan, tvOyuncuPuan, tvAltinPuan;
    CircleImageView profile_image;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_islemler);
        this.getSupportActionBar().hide();

        listView = findViewById(R.id.listIslemler);
        tvKullaniciAdSoyad = findViewById(R.id.tvKullaniciAdSoyad);
        tvOyunPuan = findViewById(R.id.tvOyunPuan);
        tvOyuncuPuan = findViewById(R.id.tvOyuncuPuan);
        tvAltinPuan = findViewById(R.id.tvAltinPuan);
        profile_image = findViewById(R.id.profile_image);


        arrayAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, array);
        listView.setAdapter(arrayAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                switch (array[position]){
                    case "Hemen Oyna":
                        //OynaActivity sayfasına yönlendir.
                        startActivity(new Intent(getApplicationContext(),OynaActivity.class));
                        break;
                    case "Sohbet":
                        //NodeJS ile Chat uygulamasını entegre et
                        startActivity(new Intent(getApplicationContext(),ChatActivity.class));
                        break;
                    case "Mesajlar":
                        break;
                    case "Profilim":
                        break;
                    case "Altın Kazan":
                        //Google Adwords reklamları
                        //Ödüllü Reklamlar, Rewarded Ads
                        break;
                    case "Oyunu Paylaş":
                        Intent i = new Intent(android.content.Intent.ACTION_SEND);
                        i.setType("text/plain");
                        i.putExtra(android.content.Intent.EXTRA_TEXT, "İsim Şehir Oyunu Play Store'da > https://play.google.com");
                        startActivity(i);
                        break;

                }

            }
        });


    }

}
