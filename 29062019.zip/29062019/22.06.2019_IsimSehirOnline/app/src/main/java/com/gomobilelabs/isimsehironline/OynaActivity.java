package com.gomobilelabs.isimsehironline;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Random;

public class OynaActivity extends AppCompatActivity implements View.OnClickListener { // Test esnasında XL ekran kullanılmıştır

    LinearLayout linearFrame;
    TextView tvSure,tvSonuc,tvIptalEt;
    ArrayList<Integer> petekIds = new ArrayList<>();
    HashMap<Integer, String> hashMap = new HashMap<>();
    Soru soru;
    ArrayList<Integer> geciciIndexler = new ArrayList<>();
    TextView tvIsim,tvSehir,tvBitki,tvEsya,tvMeslek,tvHarf,tvPuan;
    int puanim = 0;
    int karsiTarafPuan = 0;
    int seviye = 0;
    /*
    0 - isim
    1 - şehir
    2 - bitki
    3 - eşya
    4 - meslek
     */

    public void kolonUret(int kolonSayisi, int ciftAltigenSayisi, int tekAltigenSayisi) {
        //Linear layout içerisine yeni layout üretir
        for (int i = 1; i <= kolonSayisi; i++) {
            LinearLayout linearLayout = new LinearLayout(getApplicationContext());
            linearLayout.setOrientation(LinearLayout.VERTICAL);


            linearLayout.setId(i);
            if (i % 2 == 1) {
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(160, 180 * kolonSayisi);
                layoutParams.setMargins(0, 90, 0, 0);
                linearLayout.setLayoutParams(layoutParams);
            } else {
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(160, 180 * kolonSayisi);
                layoutParams.setMargins(0, 0, 0, 0);
                linearLayout.setLayoutParams(layoutParams);
            }

            linearFrame.addView(linearLayout);

            if (i % 2 == 1) {
                altigenUret(ciftAltigenSayisi, i);
            } else {
                altigenUret(tekAltigenSayisi, i);
            }


        }
    }

    public void altigenUret(int altigenSayisi, int kolonId) {
        LinearLayout linearLayout = findViewById(kolonId);

        for (int i = 100; i < 100 + altigenSayisi; i++) {
            int s = (100 * kolonId) + i;
            Button button = new Button(getApplicationContext());
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(160, 160);
            layoutParams.setMargins(0, 40, 0, 0);
            button.setLayoutParams(layoutParams);
            button.setId(s);
            button.setText(" " + s);
            button.setOnClickListener(this);
            button.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    Log.d("LOG",""+v.getId());
                    return false;
                }
            });
            button.setBackgroundResource(R.drawable.hexagon);
            linearLayout.addView(button);
            petekIds.add(s);
            hashMap.put(s,"");
        }

    }

    public ArrayList<Integer> komsulariGetir(int butonId) {
        //Değeri olmayan boş kutuları döner
        Button btn = findViewById(butonId);
        //btn.setBackgroundColor(Color.parseColor("#8197b0"));
        ArrayList<Integer> komsular = new ArrayList<>();

        if( (butonId / 100) % 2 == 0){ // eğer çift numaralı bir kolonsa yani 200,400,600,800 ... giden şekilde bir seriyse   // komşulukların eski hali bu şekilde yazılmıştı zaten
            if (petekIds.contains(butonId + 1)) {
                char ch = komsuyuKontrolEt(butonId + 1);
                if(ch==0){
                    komsular.add(butonId+1);
                }
            }
            if (petekIds.contains(butonId - 1)) {
                char ch = komsuyuKontrolEt(butonId - 1);
                if(ch==0){
                    komsular.add(butonId-1);
                }
            }
            if (petekIds.contains(butonId - 100)) {
                char ch = komsuyuKontrolEt(butonId - 100);
                if(ch==0){
                    komsular.add(butonId-100);
                }
            }
            if (petekIds.contains(butonId + 100)) {
                char ch = komsuyuKontrolEt(butonId + 100);
                if(ch==0){
                    komsular.add(butonId+100);
                }
            }
            if (petekIds.contains(butonId - 99)) {
                char ch = komsuyuKontrolEt(butonId - 99);
                if(ch==0){
                    komsular.add(butonId-99);
                }
            }
            if (petekIds.contains(butonId + 101)) {
                char ch = komsuyuKontrolEt(butonId + 101);
                if(ch==0){
                    komsular.add(butonId+101);
                }
            }

        }else{  // eğer tek sayıyla başlayan bir kolon ise +101 yerine -101 i komşu olarak görmeli  -99 yerine de +99 u görmeli
            if (petekIds.contains(butonId + 1)) {
                char ch = komsuyuKontrolEt(butonId + 1);
                if(ch==0){
                    komsular.add(butonId+1);
                }
            }
            if (petekIds.contains(butonId - 1)) {
                char ch = komsuyuKontrolEt(butonId - 1);
                if(ch==0){
                    komsular.add(butonId-1);
                }
            }
            if (petekIds.contains(butonId - 100)) {
                char ch = komsuyuKontrolEt(butonId - 100);
                if(ch==0){
                    komsular.add(butonId-100);
                }
            }
            if (petekIds.contains(butonId + 100)) {
                char ch = komsuyuKontrolEt(butonId + 100);
                if(ch==0){
                    komsular.add(butonId+100);
                }
            }
            if (petekIds.contains(butonId + 99)) {
                char ch = komsuyuKontrolEt(butonId + 99);
                if(ch==0){
                    komsular.add(butonId+99);
                }
            }
            if (petekIds.contains(butonId - 101)) {
                char ch = komsuyuKontrolEt(butonId - 101);
                if(ch==0){
                    komsular.add(butonId-101);
                }
            }
        }


        return komsular;
    }

    public char komsuyuKontrolEt(int butonId){
        char ch = '@';
        if(hashMap.containsKey(butonId)){
            if(hashMap.get(butonId).isEmpty()){
                ch = 0;
            }else{
                ch =  hashMap.get(butonId).charAt(0);
            }
        }
        return ch;
    }

    public int rastgeleBosKutuCagir(){

        ArrayList<String> valuesList = new ArrayList<String>(hashMap.values());
        ArrayList<Integer> keyList = new ArrayList<Integer>(hashMap.keySet());
        int randomIndex = new Random().nextInt(keyList.size());
        String randomValue = valuesList.get(randomIndex);
        int randomKey = keyList.get(randomIndex);

        return randomKey;
    }

    public void kelimeyiYerlestir(String kelime,ArrayList<Integer> butonIds){
        for (int i=0; i<butonIds.size(); i++){
            Button button = findViewById(butonIds.get(i));
            button.setText(""+kelime.charAt(i));
        }
    }
    /*if(komsular.size()>0){
        int rastgele = random.nextInt(komsular.size());
        int belirlenenButonId = komsular.get(rastgele) ;
        //if(komsulariGetir(komsular.get(rastgele)))
        Log.d("YazılacakYer", String.valueOf(komsular.get(rastgele)));
        Button btn2 = findViewById(komsular.get(rastgele));
        btn2.setText(""+kelime.charAt(i));
        baslangicIndex = komsular.get(rastgele);
        hashMap.put(baslangicIndex,""+kelime.charAt(i));

    }*/


    public void sekilUret(String kelime){
        int baslangicIndex = rastgeleBosKutuCagir();
        /*
        Button btn = findViewById(baslangicIndex);
        btn.setText(""+kelime.charAt(0));
        hashMap.put(baslangicIndex,""+kelime.charAt(0));
        */
        Random random = new Random();
        for(int i=0; i<kelime.length(); i++){
           //Log.d("TEST","BAŞLANGIÇ İNDEX "+baslangicIndex);

            ArrayList<Integer> komsular = komsulariGetir(baslangicIndex);
            if(komsular.size()==0){
                Log.d("Komsu Bulunamadı", String.valueOf(baslangicIndex)); //hangi index için komşu bulamadığını yazan kısım
            }

            if(komsular.size()>0){
                int rastgele = random.nextInt(komsular.size());
                int belirlenenButonId = komsular.get(rastgele); //komsular.get(rastgele) metodunu 4 kere çağırmak yerine 1 kere çağırıp değişkene atadık
                Log.d("YazılacakYer", String.valueOf(belirlenenButonId));
                Button btn2 = findViewById(belirlenenButonId);
                //Log.d("LOG_ID",""+belirlenenButonId);
                btn2.setText(""+kelime.charAt(i));
                baslangicIndex = belirlenenButonId;
                hashMap.put(belirlenenButonId,""+kelime.charAt(i));
            }
            //komsuyuKontrolEt(baslangicIndex);
        }

    }

    public int toplamPetekSayisi(int kolonSayisi){
        int sayi = 0;
        for (int i = 1; i <= kolonSayisi; i++) {
            LinearLayout layout = findViewById(i);
            sayi+=layout.getChildCount();
        }
        return sayi;
    }
    public int bosButonSayisi(){
        int sayi =0;
        for (String value : hashMap.values()) {

            if("".equals(value)){
                sayi++;
            }
        }
        return sayi;
    }

    public boolean kontrolEt(){
        boolean b = true;
        int toplamKarakter = soru.getKarakterSayisi();
        int toplamPetekSayisi = toplamPetekSayisi(7);
        int bosButonSayisi = bosButonSayisi();
        if((toplamPetekSayisi-bosButonSayisi)==toplamKarakter){
            //Tümü yerleştirildi
            b = false;
        }else{
            //Tümü Yerleştirilemedi
        }
        return b;
    }

    public void tamamenYenile(int kolonSayisi){
        //Butonları sil
        for (int i = 1; i <= kolonSayisi; i++) {
            LinearLayout layout = findViewById(i);
            layout.removeAllViews();
        }
        for (Iterator<HashMap.Entry<Integer, String>> it = hashMap.entrySet().iterator();
             it.hasNext(); ) {
            HashMap.Entry<Integer, String> pair = it.next();
            pair.setValue("");
        }

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oyna);

        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        tvSure = findViewById(R.id.tvSure);
        tvSonuc = findViewById(R.id.tvSonuc);
        tvIptalEt = findViewById(R.id.tvIptalEt);
        linearFrame = findViewById(R.id.linearFrame);
        tvIsim = findViewById(R.id.tvIsim);
        tvSehir = findViewById(R.id.tvSehir);
        tvBitki = findViewById(R.id.tvBitki);
        tvEsya = findViewById(R.id.tvEsya);
        tvMeslek = findViewById(R.id.tvMeslek);
        tvHarf = findViewById(R.id.tvHarf);
        tvPuan = findViewById(R.id.tvPuan);
        tvIptalEt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                geciciIndexler.clear();
                tvSonuc.setText("");
            }
        });

        kolonUret(8, 5, 6);
        //ArrayList<Integer> komsular = komsulariGetir(702);
        //this.setTitle("Boş komşular: "+komsular.size());

        //Log.d("KEY",rastgeleBosKutuCagir()+"");
        //Log.d("KEY",rastgeleBosKutuCagir()+"");


        soru = new Soru(1,"şerif","istanbul","turp","sandalye","öğretmen");
        sekilUret(soru.getIsim());
        sekilUret(soru.getSehir());
        sekilUret(soru.getBitki());
        sekilUret(soru.getEsya());
        sekilUret(soru.getMeslek());
        tvHarf.setText("Harf: "+ soru.getIsim().toUpperCase().charAt(0));



        /*
        while (kontrolEt()){
            tamamenYenile(7);
            sekilUret(soru.getIsim());
            sekilUret(soru.getSehir());
            sekilUret(soru.getBitki());
            sekilUret(soru.getEsya());
            sekilUret(soru.getMeslek());
        }
        */





        //Log.d("SAYI_PETEK",+"");
        //Log.d("SAYI_BOSBUTON",+"");


        /*
        ArrayList<Integer> isimIndexes = new ArrayList<>();
        isimIndexes.add(600);
        isimIndexes.add(700);
        isimIndexes.add(800);
        kelimeyiYerlestir("ADA",isimIndexes);
        */

        //sekilUret("SOFTWAREDEVELOPERARANIYORMUS");

        //hashMap.put(704,"a");
        /*
        char ch = komsuyuKontrolEt(704);
        if(ch!=0){
            this.setTitle("704 dolu");
        }else{
            this.setTitle("704 boş");
        }
        */


        new CountDownTimer(201000, 1000) {
            public void onTick(long millisUntilFinished) {
                tvSure.setText("" + millisUntilFinished / 1000);
            }

            public void onFinish() {
                //Log.d("TEST","done!");
            }
        }.start();

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        tvSonuc.setText(tvSonuc.getText()+((Button)v).getText().toString());
        geciciIndexler.add(v.getId());
        /*
        tvIsim = findViewById(R.id.tvIsim);
        tvSehir = findViewById(R.id.tvSehir);
        tvBitki = findViewById(R.id.tvBitki);
        tvEsya = findViewById(R.id.tvEsya);
        tvMeslek = findViewById(R.id.tvMeslek);
         */

        String deger = "";
        if(seviye==0){
            deger = soru.getIsim();
        }else if(seviye==1){
            deger = soru.getSehir();
        }else if(seviye==2){
            deger = soru.getBitki();
        }else if(seviye==3){
            deger = soru.getEsya();
        }else if(seviye==4){
            deger = soru.getMeslek();
        }


        if(tvSonuc.getText().equals(deger)){
            for(int i=0; i<geciciIndexler.size(); i++){
                Button btn = findViewById(geciciIndexler.get(i));
                btn.setVisibility(View.INVISIBLE);
            }
            tvSonuc.setText("");
            geciciIndexler.clear();
            seviye+=1;
            puanim += 10;
            tvPuan.setText("Puan: "+puanim);

            if(seviye==1){
                deger = soru.getSehir();
            }else if(seviye==2){
                deger = soru.getBitki();
            }else if(seviye==3){
                deger = soru.getEsya();
            }else if(seviye==4){
                deger = soru.getMeslek();
            }

            String harf = String.valueOf(deger.charAt(0)).toUpperCase();
            tvHarf.setText("Harf: "+ harf);

            if(seviye==1){
                tvIsim.setTextColor(Color.parseColor("#737373"));
                tvSehir.setTextColor(Color.parseColor("#ffffff"));
                tvBitki.setTextColor(Color.parseColor("#737373"));
                tvEsya.setTextColor(Color.parseColor("#737373"));
                tvMeslek.setTextColor(Color.parseColor("#737373"));
            }else if(seviye==2){
                tvIsim.setTextColor(Color.parseColor("#737373"));
                tvSehir.setTextColor(Color.parseColor("#737373"));
                tvBitki.setTextColor(Color.parseColor("#ffffff"));
                tvEsya.setTextColor(Color.parseColor("#737373"));
                tvMeslek.setTextColor(Color.parseColor("#737373"));
            }else if(seviye==3){
                tvIsim.setTextColor(Color.parseColor("#737373"));
                tvSehir.setTextColor(Color.parseColor("#737373"));
                tvBitki.setTextColor(Color.parseColor("#737373"));
                tvEsya.setTextColor(Color.parseColor("#ffffff"));
                tvMeslek.setTextColor(Color.parseColor("#737373"));

            }else if(seviye==4){
                tvIsim.setTextColor(Color.parseColor("#737373"));
                tvSehir.setTextColor(Color.parseColor("#737373"));
                tvBitki.setTextColor(Color.parseColor("#737373"));
                tvEsya.setTextColor(Color.parseColor("#737373"));
                tvMeslek.setTextColor(Color.parseColor("#ffffff"));
            }
        }

    }


}
