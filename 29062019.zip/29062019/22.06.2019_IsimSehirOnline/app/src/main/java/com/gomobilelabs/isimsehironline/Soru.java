package com.gomobilelabs.isimsehironline;

public class Soru {
    private int id;
    private String isim;
    private String sehir;
    private String bitki;
    private String esya;
    private String meslek;
    private int karakterSayisi;

    public Soru() {
    }

    public Soru(int id, String isim, String sehir, String bitki, String esya, String meslek) {
        this.id = id;
        this.isim = isim;
        this.sehir = sehir;
        this.bitki = bitki;
        this.esya = esya;
        this.meslek = meslek;
        karakterSayisi = isim.length()+sehir.length()+bitki.length()+esya.length()+meslek.length();
    }

    public int getKarakterSayisi() {
        return karakterSayisi;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIsim() {
        return isim;
    }

    public void setIsim(String isim) {
        this.isim = isim;
    }

    public String getSehir() {
        return sehir;
    }

    public void setSehir(String sehir) {
        this.sehir = sehir;
    }

    public String getBitki() {
        return bitki;
    }

    public void setBitki(String bitki) {
        this.bitki = bitki;
    }

    public String getEsya() {
        return esya;
    }

    public void setEsya(String esya) {
        this.esya = esya;
    }

    public String getMeslek() {
        return meslek;
    }

    public void setMeslek(String meslek) {
        this.meslek = meslek;
    }
}
