package com.gomobilelabs.isimsehironline;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.github.nkzawa.emitter.Emitter;
import com.github.nkzawa.socketio.client.IO;
import com.github.nkzawa.socketio.client.Socket;

import java.net.URISyntaxException;
import java.util.ArrayList;

public class ChatActivity extends AppCompatActivity {
    Socket mSocket;
    ArrayAdapter<String> arrayAdapter;
    ArrayList<String> liste = new ArrayList<>();
    EditText etMesaj;
    Button btnGonder;
    ListView listViewChat;

    /*
    roomId
    userTokenId1
    userTokenId2
    userId1
    userId2
    userName1
    userName2
    harf
    userPoint1
    userPoint2
    petekData(JSON)
     */



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        listViewChat = findViewById(R.id.listViewChat);
        etMesaj = findViewById(R.id.etChatMesaj);
        btnGonder = findViewById(R.id.btnMesajGonder);


        arrayAdapter = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_1,liste);
        listViewChat.setAdapter(arrayAdapter);

        try {
            mSocket = IO.socket("http://10.1.9.14:4002");
            // Soket sunucusundan anlık değer almak
            mSocket.on("mesajAl", new Emitter.Listener() {
                @Override
                public void call(final Object... args) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            liste.add(args[0].toString());
                            arrayAdapter.notifyDataSetChanged();
                        }
                    });
                    Log.d("RESPONSE",args[0].toString());
                }
            });
            //Sokete bağlantı sağladık.
            mSocket.connect();

            btnGonder.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //Node sunucusuna mesaj metodu içerisine string değer gönderdik.
                    mSocket.emit("mesaj",etMesaj.getText().toString());
                }
            });

        } catch (URISyntaxException e) {
            e.printStackTrace();
        }


    }
}
