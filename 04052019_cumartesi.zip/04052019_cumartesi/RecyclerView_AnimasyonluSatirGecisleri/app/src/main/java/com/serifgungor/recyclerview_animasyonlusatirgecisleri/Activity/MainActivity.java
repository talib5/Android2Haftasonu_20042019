package com.serifgungor.recyclerview_animasyonlusatirgecisleri.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.serifgungor.recyclerview_animasyonlusatirgecisleri.Adapter.AdapterBloglar;
import com.serifgungor.recyclerview_animasyonlusatirgecisleri.Model.Bloglar;
import com.serifgungor.recyclerview_animasyonlusatirgecisleri.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    RecyclerView recyclerView;
    ArrayList<Bloglar> bloglar = new ArrayList<>();
    AdapterBloglar adapterBloglar;

    RequestQueue queue;
    StringRequest request;



    public void doldur() {

        request = new StringRequest(
                "https://serifgungor.com/content/api/post/blogs.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        //Log.d("WEB_RESPONSE",response);

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArray = jsonObject.optJSONArray("blogs");

                            for (int i=0; i<jsonArray.length(); i++){

                                JSONObject item = jsonArray.getJSONObject(i);

                                Bloglar blog = new Bloglar();
                                blog.setUrl(item.getString("url"));
                                blog.setUpdatetime(item.getString("updatetime"));
                                blog.setSharetime(item.getString("sharetime"));
                                blog.setImage(item.getString("image"));
                                blog.setId(item.getString("id"));
                                blog.setBlog_seo_title(item.getString("blog_seo_title"));
                                blog.setBlog_do_viewcount(item.getString("blog_do_viewcount"));
                                bloglar.add(blog);

                            }
                            adapterBloglar.notifyDataSetChanged();

                            Log.d("LOGG_","size"+bloglar.size());


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        );
        queue.add(request);

        /*
        for(int i=0; i<sayi; i++){
            bloglar.add(
                    new Uyeler(
                            "Ad Soyad"+i,
                            "Email"+i,
                            "http://www.personalbrandingblog.com/wp-content/uploads/2017/08/blank-profile-picture-973460_640.png"
                    )
            );
        }
        */
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        queue = Volley.newRequestQueue(getApplicationContext());

        recyclerView = findViewById(R.id.recyclerView);
        doldur();
        adapterBloglar = new AdapterBloglar(getApplicationContext(),bloglar);

        /*
        LinearLayoutManager, satırların alt alta gösterilmesi için
        GridLayoutManager
        StaggeredGridLayoutManager
         */


        int resId = R.anim.layout_animation_fall_down;
        LayoutAnimationController animation = AnimationUtils.loadLayoutAnimation(getApplicationContext(), resId);
        //recyclerView.setItemAnimator(animation);


        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapterBloglar);

    }
}
