package com.serifgungor.recyclerview_animasyonlusatirgecisleri.Holder;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.serifgungor.recyclerview_animasyonlusatirgecisleri.R;

public class HolderBloglar extends RecyclerView.ViewHolder {

    public ImageView ivBlogPhoto;
    public TextView txtTitle;
    public TextView txtViewCount;

    public HolderBloglar(@NonNull View itemView) {
        super(itemView);
        ivBlogPhoto = itemView.findViewById(R.id.ivBlogPhoto);
        txtTitle = itemView.findViewById(R.id.txtTitle);
        txtViewCount = itemView.findViewById(R.id.txtViewCount);
    }
}
