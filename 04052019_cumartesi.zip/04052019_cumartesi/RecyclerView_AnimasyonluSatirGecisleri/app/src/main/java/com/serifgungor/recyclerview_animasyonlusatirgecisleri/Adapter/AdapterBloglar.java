package com.serifgungor.recyclerview_animasyonlusatirgecisleri.Adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.bumptech.glide.Glide;
import com.serifgungor.recyclerview_animasyonlusatirgecisleri.Holder.HolderBloglar;
import com.serifgungor.recyclerview_animasyonlusatirgecisleri.Model.Bloglar;
import com.serifgungor.recyclerview_animasyonlusatirgecisleri.R;

import java.util.ArrayList;

public class AdapterBloglar extends RecyclerView.Adapter<HolderBloglar> {
    private Context context;
    private ArrayList<Bloglar> bloglar = new ArrayList<>();


    public AdapterBloglar() {
    }

    public AdapterBloglar(Context context, ArrayList<Bloglar> bloglar) {
        this.context = context;
        this.bloglar = bloglar;
    }

    @NonNull
    @Override
    public HolderBloglar onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        // Satır görüntüsünün layout'a bağlanması işlemini yapar

        View v = LayoutInflater.from(context).inflate(R.layout.item_layout,viewGroup,false);

        return new HolderBloglar(v);
    }

    @Override
    public void onBindViewHolder(@NonNull HolderBloglar holderBloglar, int i) {
        // kaçıncı indiste isek, arraylistte ilgili modelin değerlerini
        // ilgili nesneler içerisine ata

        Animation animation = AnimationUtils.loadAnimation(holderBloglar.itemView.getContext(), R.anim.item_animation_fall_down);
        holderBloglar.itemView.startAnimation(animation);

        holderBloglar.txtTitle.setText(bloglar.get(i).getBlog_seo_title());
        holderBloglar.txtViewCount.setText(bloglar.get(i).getBlog_do_viewcount());

        Glide
                .with(context)
                .load("https://serifgungor.com/"+bloglar.get(i).getImage())
                .into(holderBloglar.ivBlogPhoto);


    }

    @Override
    public int getItemCount() {
        return bloglar.size();
    }

}
