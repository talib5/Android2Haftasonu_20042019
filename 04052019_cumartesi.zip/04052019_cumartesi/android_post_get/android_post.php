<?php


/*
100 - sayfaya get tipi ile bağlandı
200 - sayfaya get tipi ile bağlanmadı.
*/


if($_SERVER['REQUEST_METHOD']=="POST"){
	echo "100";
}else{
	echo "200";
}



?>