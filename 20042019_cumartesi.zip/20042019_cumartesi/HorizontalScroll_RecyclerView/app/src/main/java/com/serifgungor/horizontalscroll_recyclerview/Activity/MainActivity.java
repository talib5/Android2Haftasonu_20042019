package com.serifgungor.horizontalscroll_recyclerview.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.serifgungor.horizontalscroll_recyclerview.Adapter.RecyclerViewAdapterApp;
import com.serifgungor.horizontalscroll_recyclerview.Model.App;
import com.serifgungor.horizontalscroll_recyclerview.R;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    List<App> apps;
    RecyclerViewAdapterApp adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);

        apps = new ArrayList<>();

        apps.add(new App(
                1,
                "WhatsApp",
                "https://lh3.ggpht.com/mp86vbELnqLi2FzvhiKdPX31_oiTRLNyeK8x4IIrbF5eD1D5RdnVwjQP0hwMNR_JdA=s180",
                "WhatsApp Inc.",
                4.3
        ));

        apps.add(new App(
                2,
                "Facebook",
                "https://lh3.googleusercontent.com/ZZPdzvlpK9r_Df9C3M7j1rNRi7hhHRvPhlklJ3lfi5jk86Jd1s0Y5wcQ1QgbVaAP5Q=s180",
                "Facebook",
                4.3
        ));

        apps.add(new App(
                3,
                "Instagram",
                "https://lh3.googleusercontent.com/aYbdIM1abwyVSUZLDKoE0CDZGRhlkpsaPOg9tNnBktUQYsXflwknnOn2Ge1Yr7rImGk=s180",
                "Instagram",
                4.3
        ));

        apps.add(new App(
                3,
                "YouTube",
                "https://lh3.googleusercontent.com/Ned_Tu_ge6GgJZ_lIO_5mieIEmjDpq9kfgD05wapmvzcInvT4qQMxhxq_hEazf8ZsqA=s180",
                "Google LLC",
                4.3
        ));

        adapter = new RecyclerViewAdapterApp(apps);
        recyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));
        recyclerView.setAdapter(adapter);


    }
}
