package com.serifgungor.retrofitgiriskayit.Model;

import com.google.gson.annotations.SerializedName;

public class UserRegisterResponse {

    @SerializedName("registerResponse")
    private String registerResponse;

    public UserRegisterResponse(String registerResponse) {
        this.registerResponse = registerResponse;
    }

    public String getRegisterResponse() {
        return registerResponse;
    }

    public void setRegisterResponse(String registerResponse) {
        this.registerResponse = registerResponse;
    }
}
