package com.serifgungor.retrofitgiriskayit.Model;

import com.google.gson.annotations.SerializedName;

public class UserLoginResponse {

    @SerializedName("loginResponse")
    private String loginResponse;

    public UserLoginResponse() {
    }

    public UserLoginResponse(String loginResponse) {
        this.loginResponse = loginResponse;
    }

    public String getLoginResponse() {
        return loginResponse;
    }

    public void setLoginResponse(String loginResponse) {
        this.loginResponse = loginResponse;
    }
}
