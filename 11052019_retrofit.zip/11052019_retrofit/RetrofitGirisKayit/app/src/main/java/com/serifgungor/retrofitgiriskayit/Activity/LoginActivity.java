package com.serifgungor.retrofitgiriskayit.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.serifgungor.retrofitgiriskayit.Interface.MobileAppService;
import com.serifgungor.retrofitgiriskayit.Model.UserLoginResponse;
import com.serifgungor.retrofitgiriskayit.R;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class LoginActivity extends AppCompatActivity {


    EditText etUsername, etPassword;
    Button btnLogin;

    Retrofit retrofit;
    MobileAppService service;

    public void girisYap(){
        Call<UserLoginResponse> loginResponse = service.userLogin(etUsername.getText().toString(), etPassword.getText().toString());

        loginResponse.enqueue(new Callback<UserLoginResponse>() {
            @Override
            public void onResponse(Call<UserLoginResponse> call, Response<UserLoginResponse> response) {
                //istek başarılı şekilde gönderilip, sayfadan yanıt dönerse

                String loginResponse = response.body().getLoginResponse();

                //Log.d("RESPONSE",response.body().toString());

                /*
                100 - kullanıcı adı ve şifre doğrudur.
                101 - kullanıcı adı yada şifre hatalı
                200 - post tipinde istekte bulunulmadı
                 */

                switch (loginResponse) {
                    case "100":
                        Toast.makeText(getApplicationContext(), "Kullanıcı adı ve şifre doğru", Toast.LENGTH_LONG).show();
                        break;
                    case "101":
                        Toast.makeText(getApplicationContext(), "Kullanıcı adı yada şifre hatalı", Toast.LENGTH_LONG).show();
                        break;
                    case "200":
                        Toast.makeText(getApplicationContext(), "Bağlantı türü hatası", Toast.LENGTH_LONG).show();
                        break;
                }


            }

            @Override
            public void onFailure(Call<UserLoginResponse> call, Throwable t) {
                //istek başarısız olursa

            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        etPassword = findViewById(R.id.etLoginPassword);
        etUsername = findViewById(R.id.etLoginUsername);
        btnLogin = findViewById(R.id.btnLoginIslem);


        retrofit = new Retrofit.Builder().baseUrl("http://10.1.9.14:7331/androiduygulamasi/").addConverterFactory(GsonConverterFactory.create()).build();
        service = retrofit.create(MobileAppService.class);


        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                girisYap();
            }
        });


    }
}
