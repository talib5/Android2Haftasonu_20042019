package com.serifgungor.retrofitgiriskayit.Interface;

import com.serifgungor.retrofitgiriskayit.Model.UserLoginResponse;
import com.serifgungor.retrofitgiriskayit.Model.UserRegisterResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface MobileAppService {

    @POST("register.php")
    Call<UserRegisterResponse> userRegister(
            @Query("username") String username,
            @Query("password") String password,
            @Query("email") String email,
            @Query("namesurname") String namesurname
    );


    @POST("login.php")
    Call<UserLoginResponse> userLogin(
            @Query("username") String username,
            @Query("password") String password
    );

}
