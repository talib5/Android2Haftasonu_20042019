package com.serifgungor.retrofitgiriskayit.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import com.serifgungor.retrofitgiriskayit.Interface.MobileAppService;
import com.serifgungor.retrofitgiriskayit.Model.UserLoginResponse;
import com.serifgungor.retrofitgiriskayit.Model.UserRegisterResponse;
import com.serifgungor.retrofitgiriskayit.R;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class RegisterActivity extends AppCompatActivity {

    Retrofit retrofit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        retrofit = new Retrofit.Builder().baseUrl("http://10.1.9.14:7331/androiduygulamasi/").build();


        MobileAppService service = retrofit.create(MobileAppService.class);
        Call<UserRegisterResponse> registerResponse = service.userRegister("username","12356","email","namesurname");

        /*
        Web sayfasına istekte bulun.
        Enque içerisindeki onResponse ise, istekte bulunduğun web sayfasından yanıt dönsün.

         */
        registerResponse.enqueue(new Callback<UserRegisterResponse>() {
            @Override
            public void onResponse(Call<UserRegisterResponse> call, Response<UserRegisterResponse> response) {

                /*
                RESPONSE CODES

                100 - Kayıt başarılıdır.
                101 - Kullanıcı adı zaten sistemde kayıtlı
                200 - Veritabanına bağlanılamadı
                300 - Bağlantı protokolü hatası (POST tipinde istekte bulunulmadıysa)
                 */



            }

            @Override
            public void onFailure(Call<UserRegisterResponse> call, Throwable t) {
                // İstek başarısız olursa
                /*
                Sunucu kapalı olabilir,
                bağlanmak istenilen sayfa sunucuda olmayabilir,
                İnternet bağlantımız o esnada kesilmiş olabilir.
                 */

            }
        });





    }
}
