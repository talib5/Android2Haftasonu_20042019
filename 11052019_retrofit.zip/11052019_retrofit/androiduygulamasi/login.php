<?php
require_once("db.php");

ob_start();
header("Content-type:application/json");

$response = "{";

if($_SERVER['REQUEST_METHOD']=="POST"){
	$db = new Db("localhost","android_app","root","","utf8");

	$username = @$_POST['username'];
	$password = @$_POST['password'];
	$db->query("SELECT * FROM users WHERE username='".$username."' and passw='".$password."'");
	$db->select();
	
	if($db->count()==1){
		// select sorgusundan yanıt döndüyse
		//print_r($db->select());
		$response .= '"loginResponse":"100"';

	}else{
		// select sorgusundan dönen yanıt sayısı 0 ise
		$response .= '"loginResponse":"101"';
	}
}else{
	$response .= '"loginResponse":"200"';
}

$response .= "}";
echo $response;




?>