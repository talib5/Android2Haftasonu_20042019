<?php
require_once("db.php");

$response = "[";

if($_SERVER['REQUEST_METHOD']=="POST"){
	$db = new Db("localhost","android_app","root","","utf8");

	$username = @$_POST['username'];
	$password = @$_POST['password'];
	$email = @$_POST['email'];
	$namesurname = @$_POST['namesurname'];
	$date = time();
	
	$db->query("SELECT * FROM users WHERE email='$email'");
	$db->select();
	
	
	
	if($db->count()==1){
		// kullanıcı daha önce kayıtlı ise
		$response .= "registerResponse:'101'";

	}else{
		// kullanıcı daha önce kayıtlı değil ise
		
		$db->query("INSERT INTO users(namesurname,username,password,email,register_date) VALUES ('$namesurname','$username','$password','$email','$date')");
		$db->insert();
		
		$response .= "registerResponse:'100'";
	}
}else{
	$response .= "registerResponse:'300'";
}

$response .= "]";

echo json_encode($response);



?>