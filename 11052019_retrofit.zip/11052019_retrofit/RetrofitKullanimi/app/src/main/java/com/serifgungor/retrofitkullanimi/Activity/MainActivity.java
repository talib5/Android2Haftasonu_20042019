package com.serifgungor.retrofitkullanimi.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.serifgungor.retrofitkullanimi.Interface.GitHubService;
import com.serifgungor.retrofitkullanimi.Model.Repo;
import com.serifgungor.retrofitkullanimi.R;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    Retrofit retrofit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        retrofit = new Retrofit.Builder().baseUrl("https://api.github.com/").addConverterFactory(GsonConverterFactory.create()).build();


        GitHubService service = retrofit.create(GitHubService.class);
        Call<List<Repo>> repos = service.listRepos("serifgungor");
        
        repos.enqueue(new Callback<List<Repo>>() {
            @Override
            public void onResponse(Call<List<Repo>> call, Response<List<Repo>> response) {
                if(response.isSuccessful()){

                    for(int i=0; i<response.body().size(); i++){
                        Log.d("WEBSERVICE",response.body().get(i).getName());
                    }
                    /*
                    Response{protocol=http/1.1, code=200, message=OK, url=https://api.github.com/users/serifgungor/repos}
                    Log.d("WEBSERVICE",response.toString());
                    */
                }
            }

            @Override
            public void onFailure(Call<List<Repo>> call, Throwable t) {

            }
        });



    }
}
