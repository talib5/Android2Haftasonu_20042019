package com.gomobilelabs.isimsehironline;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class OynaActivity extends AppCompatActivity {

    LinearLayout linearFrame;
    TextView tvSure;
    ArrayList<Integer> petekIds = new ArrayList<>();
    HashMap<Integer, String> hashMap = new HashMap<>();
    Soru soru;

    public void kolonUret(int uzunluk, int ciftAltigenSayisi, int tekAltigenSayisi) {
        //Linear layout içerisine yeni layout üretir
        for (int i = 1; i < uzunluk; i++) {
            LinearLayout linearLayout = new LinearLayout(getApplicationContext());
            linearLayout.setOrientation(LinearLayout.VERTICAL);


            linearLayout.setId(i);
            if (i % 2 == 1) {
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(160, 180 * uzunluk);
                layoutParams.setMargins(0, 90, 0, 0);
                linearLayout.setLayoutParams(layoutParams);
            } else {
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(160, 180 * uzunluk);
                layoutParams.setMargins(0, 0, 0, 0);
                linearLayout.setLayoutParams(layoutParams);
            }

            linearFrame.addView(linearLayout);

            if (i % 2 == 1) {
                altigenUret(ciftAltigenSayisi, i);
            } else {
                altigenUret(tekAltigenSayisi, i);
            }


        }
    }

    public void altigenUret(int altigenSayisi, int kolonId) {
        LinearLayout linearLayout = findViewById(kolonId);

        for (int i = 100; i < 100 + altigenSayisi; i++) {
            int s = (100 * kolonId) + i;
            Button button = new Button(getApplicationContext());
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(160, 160);
            layoutParams.setMargins(0, 40, 0, 0);
            button.setLayoutParams(layoutParams);
            button.setId(s);
            button.setText(" " + s);
            button.setBackgroundResource(R.drawable.hexagon);
            linearLayout.addView(button);
            petekIds.add(s);
            hashMap.put(s,"");
        }

    }

    public ArrayList<Integer> komsulariGetir(int butonId) {
        //Değeri olmayan boş kutuları döner
        Button btn = findViewById(butonId);
        //btn.setBackgroundColor(Color.parseColor("#8197b0"));
        ArrayList<Integer> komsular = new ArrayList<>();

        if (petekIds.contains(butonId + 1)) {
            btn = findViewById(butonId+1);
            //btn.setBackgroundColor(Color.parseColor("#8197b0"));
            char ch = komsuyuKontrolEt(butonId + 1);
            if(ch==0){
                komsular.add(butonId+1);
            }
        }
        if (petekIds.contains(butonId - 1)) {
            btn = findViewById(butonId-1);
            //btn.setBackgroundColor(Color.parseColor("#8197b0"));
            char ch = komsuyuKontrolEt(butonId - 1);
            if(ch==0){
                komsular.add(butonId-1);
            }
        }
        if (petekIds.contains(butonId - 100)) {
            btn = findViewById(butonId-100);
            //btn.setBackgroundColor(Color.parseColor("#8197b0"));
            char ch = komsuyuKontrolEt(butonId - 100);
            if(ch==0){
                komsular.add(butonId-100);
            }
        }
        if (petekIds.contains(butonId + 100)) {
            btn = findViewById(butonId+100);
            //btn.setBackgroundColor(Color.parseColor("#8197b0"));
            char ch = komsuyuKontrolEt(butonId + 100);
            if(ch==0){
                komsular.add(butonId+100);
            }
        }
        if (petekIds.contains(butonId - 99)) {
            btn = findViewById(butonId-99);
            //btn.setBackgroundColor(Color.parseColor("#8197b0"));
            char ch = komsuyuKontrolEt(butonId - 99);
            if(ch==0){
                komsular.add(butonId-99);
            }
        }
        if (petekIds.contains(butonId + 101)) {
            btn = findViewById(butonId+101);
            //btn.setBackgroundColor(Color.parseColor("#8197b0"));
            char ch = komsuyuKontrolEt(butonId + 101);
            if(ch==0){
                komsular.add(butonId+101);
            }
        }
        return komsular;
    }

    public char komsuyuKontrolEt(int butonId){
        char ch = '@';
        if(hashMap.containsKey(butonId)){
            if(hashMap.get(butonId).isEmpty()){
                ch = 0;
            }else{
                ch =  hashMap.get(butonId).charAt(0);
            }
        }
        return ch;
    }

    public int rastgeleBosKutuCagir(){

        ArrayList<String> valuesList = new ArrayList<String>(hashMap.values());
        ArrayList<Integer> keyList = new ArrayList<Integer>(hashMap.keySet());
        int randomIndex = new Random().nextInt(keyList.size());
        String randomValue = valuesList.get(randomIndex);
        int randomKey = keyList.get(randomIndex);

        return randomKey;
    }

    public void kelimeyiYerlestir(String kelime,ArrayList<Integer> butonIds){
        for (int i=0; i<butonIds.size(); i++){
            Button button = findViewById(butonIds.get(i));
            button.setText(""+kelime.charAt(i));
        }
    }

    public void sekilUret(String kelime){
        int baslangicIndex = rastgeleBosKutuCagir();
        /*
        Button btn = findViewById(baslangicIndex);
        btn.setText(""+kelime.charAt(0));
        hashMap.put(baslangicIndex,""+kelime.charAt(0));
        */
        Random random = new Random();



        for(int i=0; i<kelime.length(); i++){
           // Log.d("TEST","BAŞLANGIÇ İNDEX "+baslangicIndex);
            ArrayList<Integer> komsular = komsulariGetir(baslangicIndex);
            for(int j=0; j<komsular.size(); j++){
                Log.d("TEST","BAŞLANGIÇ: "+baslangicIndex+" "+komsular.get(j));
            }
            if(komsular.size()>0){
                int rastgele = random.nextInt(komsular.size());
                Button btn2 = findViewById(komsular.get(rastgele));
                btn2.setText(""+kelime.charAt(i));
                baslangicIndex = komsular.get(rastgele);
                hashMap.put(baslangicIndex,""+kelime.charAt(i));

            }

            //komsuyuKontrolEt(baslangicIndex);
        }

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oyna);

        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        tvSure = findViewById(R.id.tvSure);
        linearFrame = findViewById(R.id.linearFrame);

        kolonUret(8, 5, 6);
        ArrayList<Integer> komsular = komsulariGetir(702);
        this.setTitle("Boş komşular: "+komsular.size());

        //Log.d("KEY",rastgeleBosKutuCagir()+"");
        //Log.d("KEY",rastgeleBosKutuCagir()+"");

        soru = new Soru(1,"ada","istanbul","turp","sandalye","öğretmen");

        /*
        ArrayList<Integer> isimIndexes = new ArrayList<>();
        isimIndexes.add(600);
        isimIndexes.add(700);
        isimIndexes.add(800);
        kelimeyiYerlestir("ADA",isimIndexes);
        */
        sekilUret("ŞERİF");

        //hashMap.put(704,"a");
        /*
        char ch = komsuyuKontrolEt(704);
        if(ch!=0){
            this.setTitle("704 dolu");
        }else{
            this.setTitle("704 boş");
        }
        */


        new CountDownTimer(201000, 1000) {
            public void onTick(long millisUntilFinished) {
                tvSure.setText("" + millisUntilFinished / 1000);
            }

            public void onFinish() {
                //Log.d("TEST","done!");
            }
        }.start();

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
