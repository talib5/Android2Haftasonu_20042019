package yenitakim.burhangok.ismek.recyclerview_searchviewkullanimi.Holder;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import yenitakim.burhangok.ismek.recyclerview_searchviewkullanimi.R;

public class UlkeHolder extends RecyclerView.ViewHolder {

    public ImageView ivResim;
    public TextView tvUlkeAdi,tvUlkeKodu,tvUlkeBaskent,tvUlkeKurulus;

    public UlkeHolder(View itemView) {
        super(itemView);

        tvUlkeAdi = itemView.findViewById(R.id.tvUlkeAdi);
        tvUlkeKodu = itemView.findViewById(R.id.tvTelKodu);
        tvUlkeBaskent = itemView.findViewById(R.id.tvBaskent);
        tvUlkeKurulus = itemView.findViewById(R.id.tvKurulus);
        ivResim = itemView.findViewById(R.id.ivUlkeBayrak);
    }

}