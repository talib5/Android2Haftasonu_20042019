package yenitakim.burhangok.ismek.myapplication.Adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

import yenitakim.burhangok.ismek.myapplication.Holder.HolderResim;
import yenitakim.burhangok.ismek.myapplication.Model.Resim;
import yenitakim.burhangok.ismek.myapplication.R;

public class AdapterResim extends RecyclerView.Adapter<HolderResim> {
    private ArrayList<Resim> resimler;
    private Context context;

    public AdapterResim() {
    }

    public AdapterResim(ArrayList<Resim> resimler, Context context) {
        this.resimler = resimler;
        this.context = context;
    }

    @NonNull
    @Override
    public HolderResim onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        /*
        Adapter'ın satır görüntüsü layout'una bağlanması işlemini temsil eder.
         */
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.resim_satirgoruntusu,viewGroup,false);
        return new HolderResim(v);
    }

    @Override
    public void onBindViewHolder(@NonNull HolderResim holderResim, int i) {
        /*
        Satır görüntüsünde bulunan nesnelere erişebilmek için kullanılır.
        Nesnelere erişip, metotlarına ulaşabilirsiniz.
        Varsayılan değer ataması yapabilirsiniz. (setText() gibi)
        ---
        ArrayList'den gelen değerlerin ilgili satırdaki nesne değerlerini doldurması için
        kullanılır
         */
        Glide
                .with(holderResim.itemView.getContext())
                .load(resimler.get(i).getDosya())
                .into(holderResim.ivResim);

    }

    @Override
    public int getItemCount() {
        // Kaç satır listenecek bilgisini döndürür
        return resimler.size();
    }
}
