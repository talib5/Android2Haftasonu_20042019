package yenitakim.burhangok.ismek.myapplication.Activity;

import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.util.Log;

import java.io.File;
import java.util.ArrayList;

import yenitakim.burhangok.ismek.myapplication.Adapter.AdapterResim;
import yenitakim.burhangok.ismek.myapplication.Model.Resim;
import yenitakim.burhangok.ismek.myapplication.R;

public class MainActivity extends AppCompatActivity {

    RecyclerView rvGaleri;
    AdapterResim adapterResim;
    ArrayList<Resim> resimler;


    public void konumdakiTumDosyalar(String konum){
        File dosya = Environment.getExternalStoragePublicDirectory(konum);
        File[] dosyalar = dosya.listFiles();
        for (int i=0; i<dosyalar.length; i++){
            resimler.add(new Resim(dosyalar[i]));
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //Log.d("LOCATION__",Environment.DIRECTORY_DOWNLOADS);
        //Log.d("LOCATION__",Environment.DIRECTORY_DCIM);




        rvGaleri = findViewById(R.id.rvGaleri);
        resimler = new ArrayList<>();

        konumdakiTumDosyalar(Environment.DIRECTORY_DOWNLOADS);
        //Environment.DIRECTORY_DCIM+"/Camera"
        Log.d("TEST__",resimler.size()+"");
        adapterResim = new AdapterResim(resimler,getApplicationContext());
        //Her satırda 3 kolon göstermesini istediğimiz için GridLayoutManager'i rvGaleri'ye bağladık.


        StaggeredGridLayoutManager layoutManager = new StaggeredGridLayoutManager(2,StaggeredGridLayoutManager.VERTICAL);
        //new GridLayoutManager(MainActivity.this,3)
        rvGaleri.setLayoutManager(layoutManager);
        rvGaleri.setAdapter(adapterResim);




    }
}
