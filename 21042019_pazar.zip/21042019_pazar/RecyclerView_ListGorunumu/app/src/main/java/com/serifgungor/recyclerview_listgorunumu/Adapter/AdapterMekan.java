package com.serifgungor.recyclerview_listgorunumu.Adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;
import com.serifgungor.recyclerview_listgorunumu.Holder.ViewHolderMekan;
import com.serifgungor.recyclerview_listgorunumu.Model.GezilecekMekanlar;
import com.serifgungor.recyclerview_listgorunumu.R;

import java.util.ArrayList;

public class AdapterMekan extends RecyclerView.Adapter<ViewHolderMekan> {


    public interface OnItemClickListener {
        void onItemClick(GezilecekMekanlar item);
    }

    Context context;
    ArrayList<GezilecekMekanlar> gezilecekMekanlar;
    OnItemClickListener listener;

    //Default Constructor
    public AdapterMekan(){}

    //Dolu Constructor
    public AdapterMekan(Context context, ArrayList<GezilecekMekanlar> gezilecekMekanlar, OnItemClickListener listener){
        this.context = context;
        this.gezilecekMekanlar = gezilecekMekanlar;
        this.listener = listener;
    }


    @NonNull
    @Override
    public ViewHolderMekan onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.mekan_satirgoruntusu,null);

        /*
        Metodun geri dönüş tipi ViewHolderMekan sınıfı tipindedir. Bu nesne View'dir.
        onCreateViewHolder metodu satır görüntüsünün üretilme zamanını temsil eder.
         */

        return new ViewHolderMekan(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderMekan viewHolderMekan, int i) {
        /*
        Çağırılan layout içerisindeki elemanların olaylarının tanımlanması
         */
        viewHolderMekan.tvAdres.setText(gezilecekMekanlar.get(i).getAdres());
        viewHolderMekan.tvBaslik.setText(gezilecekMekanlar.get(i).getIsim());

        Glide
                .with(context)
                .load(gezilecekMekanlar.get(i).getResim())
                .into(viewHolderMekan.ivResim);

        bind(viewHolderMekan,gezilecekMekanlar.get(i),listener);
    }

    @Override
    public int getItemCount() {
        return gezilecekMekanlar.size();
    }


    public void bind(ViewHolderMekan v, final GezilecekMekanlar item, final OnItemClickListener listener) {
        //SATIRA TIKLAMA OLAYI
        v.itemView.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                listener.onItemClick(item);
            }
        });
    }
}
