package com.serifgungor.recyclerview_listgorunumu.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.serifgungor.recyclerview_listgorunumu.Adapter.AdapterMekan;
import com.serifgungor.recyclerview_listgorunumu.Model.GezilecekMekanlar;
import com.serifgungor.recyclerview_listgorunumu.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    RecyclerView recyclerView;
    ArrayList<GezilecekMekanlar> mekanlar = new ArrayList<>();
    AdapterMekan adapterMekan;

    public void mekanlariGetir() {
        //int id, String isim, String aciklama, String adres, String resim
        mekanlar.add(new GezilecekMekanlar(
                1,
                "Ortaköy Camii",
                "açıklama",
                "adres",
                "http://mansettekiler.com/images/galeri/1465479988.jpg"
        ));
        mekanlar.add(new GezilecekMekanlar(
                2,
                "Ortaköy Camii",
                "açıklama",
                "adres",
                "http://mansettekiler.com/images/galeri/1465479988.jpg"
        ));
        mekanlar.add(new GezilecekMekanlar(
                3,
                "Ortaköy Camii",
                "açıklama",
                "adres",
                "http://mansettekiler.com/images/galeri/1465479988.jpg"
        ));
        mekanlar.add(new GezilecekMekanlar(
                4,
                "Ortaköy Camii",
                "açıklama",
                "adres",
                "http://mansettekiler.com/images/galeri/1465479988.jpg"
        ));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        mekanlariGetir();

        adapterMekan = new AdapterMekan(getApplicationContext(), mekanlar, new AdapterMekan.OnItemClickListener() {
            @Override
            public void onItemClick(GezilecekMekanlar item) {
                //SATIRA TIKLAMA OLAYI
                Toast.makeText(getApplicationContext(),
                        item.getIsim()+" - "+item.getId(), Toast.LENGTH_LONG).show();
            }
        });


        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerView.setAdapter(adapterMekan);


    }

}
