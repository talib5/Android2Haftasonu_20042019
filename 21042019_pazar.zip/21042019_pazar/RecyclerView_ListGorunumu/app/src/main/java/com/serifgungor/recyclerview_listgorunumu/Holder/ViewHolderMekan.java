package com.serifgungor.recyclerview_listgorunumu.Holder;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.serifgungor.recyclerview_listgorunumu.R;

public class ViewHolderMekan extends RecyclerView.ViewHolder {

    public ImageView ivResim;
    public TextView tvBaslik,tvAdres;

    public ViewHolderMekan(@NonNull View itemView) {
        super(itemView);
        /*
        RecyclerView nesnesinin satır görüntüsündeki nesne referansları
        ViewHolder sınıfı içerisinde tanımlanır.
         */
        ivResim = itemView.findViewById(R.id.ivResim);
        tvBaslik = itemView.findViewById(R.id.tvMekanBaslik);
        tvAdres = itemView.findViewById(R.id.tvMekanAdres);

    }

}
