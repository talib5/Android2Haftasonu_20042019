package com.gomobilelabs.isimsehironline;

import android.graphics.drawable.GradientDrawable;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OynaActivity extends AppCompatActivity {

    LinearLayout linearFrame;
    TextView tvSure;

    public void kolonUret(int uzunluk,int ciftAltigenSayisi,int tekAltigenSayisi){
        //Linear layout içerisine yeni layout üretir
        for(int i=1; i<uzunluk; i++){
            LinearLayout linearLayout = new LinearLayout(getApplicationContext());
            linearLayout.setOrientation(LinearLayout.VERTICAL);


            linearLayout.setId(i);
            if(i%2==1){
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(160,180*uzunluk);
                layoutParams.setMargins(0,90,0,0);
                linearLayout.setLayoutParams(layoutParams);
            }else{
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(160,180*uzunluk);
                layoutParams.setMargins(0,0,0,0);
                linearLayout.setLayoutParams(layoutParams);
            }

            linearFrame.addView(linearLayout);

            if(i%2==1){
                altigenUret(ciftAltigenSayisi,i);
            }else{
                altigenUret(tekAltigenSayisi,i);
            }


        }
    }

    public void altigenUret(int altigenSayisi,int kolonId){
        LinearLayout linearLayout = findViewById(kolonId);

        for(int i=100; i<100+altigenSayisi; i++){
            int s = (100*kolonId)+i;
            Button button = new Button(getApplicationContext());
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(160,160);
            layoutParams.setMargins(0,40,0,0);
            button.setLayoutParams(layoutParams);
            button.setId(s);
            button.setText(" "+s);
            button.setBackgroundResource(R.drawable.hexagon);
            linearLayout.addView(button);
        }

    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oyna);

        tvSure = findViewById(R.id.tvSure);
        linearFrame = findViewById(R.id.linearFrame);

        kolonUret(8,6,5);



        new CountDownTimer(201000, 1000) {
            public void onTick(long millisUntilFinished) {
                tvSure.setText(""+millisUntilFinished / 1000);
            }
            public void onFinish() {
                //Log.d("TEST","done!");
            }
        }.start();

    }
}
