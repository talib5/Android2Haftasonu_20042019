
package com.serifgungor.reyclerview_multipleornek2.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;

import com.serifgungor.reyclerview_multipleornek2.Adapter.RecyclerViewAdapter;
import com.serifgungor.reyclerview_multipleornek2.Model.Kisi;
import com.serifgungor.reyclerview_multipleornek2.Model.Reklam;
import com.serifgungor.reyclerview_multipleornek2.R;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    RecyclerViewAdapter adapter;
    List<Object> objects;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        objects = new ArrayList<>();
        objects.add(new Kisi(R.drawable.user1,20,"Ad Soyad 1"));
        objects.add(new Kisi(R.drawable.user2,20,"Ad Soyad 2"));
        objects.add(new Reklam("12345"));
        objects.add(new Kisi(R.drawable.user1,25,"Ad Soyad 3"));
        objects.add(new Kisi(R.drawable.user2,29,"Ad Soyad 4"));

        adapter = new RecyclerViewAdapter(objects,getApplicationContext());

        int resId = R.anim.layout_animation_fall_down;
        LayoutAnimationController animation = AnimationUtils.loadLayoutAnimation(getApplicationContext(), resId);
        recyclerView.setLayoutAnimation(animation);
        recyclerView.scheduleLayoutAnimation();

        //LİSTVİEW GÖRÜNÜMÜ
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerView.setAdapter(adapter);
        /*
        //GRİDVİEW GÖRÜNÜMÜ 2 KOLON
        recyclerView.setLayoutManager(new GridLayoutManager(getApplicationContext(),2));

        //STAGGERED GRİDVİEW GÖRÜNÜMÜ 2 KOLON
        recyclerView.setLayoutManager(new StaggeredGridLayoutManager(2,LinearLayoutManager.VERTICAL));

        //HORİZONTAL SCROLL
        recyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));

        */


    }
}
