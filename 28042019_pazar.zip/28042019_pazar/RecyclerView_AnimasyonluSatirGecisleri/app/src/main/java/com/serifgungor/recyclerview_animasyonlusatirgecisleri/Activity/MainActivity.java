package com.serifgungor.recyclerview_animasyonlusatirgecisleri.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;

import com.serifgungor.recyclerview_animasyonlusatirgecisleri.Adapter.AdapterUyeler;
import com.serifgungor.recyclerview_animasyonlusatirgecisleri.Model.Uyeler;
import com.serifgungor.recyclerview_animasyonlusatirgecisleri.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    RecyclerView recyclerView;
    ArrayList<Uyeler> uyeler = new ArrayList<>();
    AdapterUyeler adapterUyeler;

    public void doldur(int sayi){
        for(int i=0; i<sayi; i++){
            uyeler.add(
                    new Uyeler(
                            "Ad Soyad"+i,
                            "Email"+i,
                            "http://www.personalbrandingblog.com/wp-content/uploads/2017/08/blank-profile-picture-973460_640.png"
                    )
            );
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        recyclerView = findViewById(R.id.recyclerView);
        doldur(20);
        adapterUyeler = new AdapterUyeler(getApplicationContext(),uyeler);
        /*
        LinearLayoutManager, satırların alt alta gösterilmesi için
        GridLayoutManager
        StaggeredGridLayoutManager
         */


        int resId = R.anim.layout_animation_fall_down;
        LayoutAnimationController animation = AnimationUtils.loadLayoutAnimation(getApplicationContext(), resId);
        //recyclerView.setItemAnimator(animation);





        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapterUyeler);

    }
}
