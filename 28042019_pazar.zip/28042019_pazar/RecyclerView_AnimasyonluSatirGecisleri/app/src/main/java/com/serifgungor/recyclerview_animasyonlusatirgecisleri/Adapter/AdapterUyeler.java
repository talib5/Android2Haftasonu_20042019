package com.serifgungor.recyclerview_animasyonlusatirgecisleri.Adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.bumptech.glide.Glide;
import com.serifgungor.recyclerview_animasyonlusatirgecisleri.Holder.HolderUyeler;
import com.serifgungor.recyclerview_animasyonlusatirgecisleri.Model.Uyeler;
import com.serifgungor.recyclerview_animasyonlusatirgecisleri.R;

import java.util.ArrayList;

public class AdapterUyeler extends RecyclerView.Adapter<HolderUyeler> {
    private Context context;
    private ArrayList<Uyeler> uyeler = new ArrayList<>();


    public AdapterUyeler() {
    }

    public AdapterUyeler(Context context, ArrayList<Uyeler> uyeler) {
        this.context = context;
        this.uyeler = uyeler;
    }

    @NonNull
    @Override
    public HolderUyeler onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        // Satır görüntüsünün layout'a bağlanması işlemini yapar

        View v = LayoutInflater.from(context).inflate(R.layout.item_layout,viewGroup,false);

        return new HolderUyeler(v);
    }

    @Override
    public void onBindViewHolder(@NonNull HolderUyeler holderUyeler, int i) {
        // kaçıncı indiste isek, arraylistte ilgili modelin değerlerini
        // ilgili nesneler içerisine ata

        Animation animation = AnimationUtils.loadAnimation(holderUyeler.itemView.getContext(), R.anim.item_animation_fall_down);
        holderUyeler.itemView.startAnimation(animation);

        holderUyeler.txtEmail.setText(uyeler.get(i).getEmail());
        holderUyeler.txtAd.setText(uyeler.get(i).getAd());

        Glide
                .with(context)
                .load(uyeler.get(i).getProfilResim())
                .into(holderUyeler.ivResim);


    }

    @Override
    public int getItemCount() {
        return uyeler.size();
    }

}
