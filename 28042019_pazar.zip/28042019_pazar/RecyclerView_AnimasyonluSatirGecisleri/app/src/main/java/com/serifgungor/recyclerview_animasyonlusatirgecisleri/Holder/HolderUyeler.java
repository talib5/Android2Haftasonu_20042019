package com.serifgungor.recyclerview_animasyonlusatirgecisleri.Holder;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.serifgungor.recyclerview_animasyonlusatirgecisleri.R;

public class HolderUyeler extends RecyclerView.ViewHolder {

    public ImageView ivResim;
    public TextView txtEmail;
    public TextView txtAd;

    public HolderUyeler(@NonNull View itemView) {
        super(itemView);
        ivResim = itemView.findViewById(R.id.profilResim);
        txtAd = itemView.findViewById(R.id.txtAd);
        txtEmail = itemView.findViewById(R.id.txtEmail);
    }
}
