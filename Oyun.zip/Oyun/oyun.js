﻿var app = require('express')();
var server = require('http').createServer(app);
var io = require('socket.io')(server);

//web porta bağlantığı zaman index.html'i göster
app.get('/', function(req, res) {
   res.sendfile('index.html');
});

//3000 portunu dinlemeye başla
server.listen(3000, function() {
   console.log('listening on localhost:3000');
});

io.attach(server);
var aktifOyuncuSayisi = 0;

/*
RESPONSE CODES
601 - Müsait oda bulunamadı. Yeni oda üret
701 - rakipCikti
*/

//socket portuna bağlantı sağlanıldıysa
io.on('connection', function(socket)
{
	console.log('Socket '+socket.id+' connected.');
	
	var srvSockets = io.sockets.sockets;
	aktifOyuncuSayisi = Object.keys(srvSockets).length;
	
	io.to("client-playerCount",{count:Object.keys(io.sockets.adapter.rooms).length});//ONLINE OYUNCU SAYISI
	io.sockets.adapter.rooms[socket.id].oyunKurma = false;
	io.sockets.adapter.rooms[socket.id].bosluk = 1;//odama katılabilecek kısı sayısı => sadece 1 kisi girebilir

	//Bu metot androidden tetiklenecek
	socket.on("server-oyunOlustur",(data)=>
	{
		var js =  JSON.parse(data);
		console.log('Oyuncu adı: '+js.oyuncuAdi);
		console.log('Petek Data: '+js.petekData);
		console.log('Token ID: '+js.tokenId);
		/*
		io.sockets.adapter.rooms[socket.id].kurucuPuan = 0;
		io.sockets.adapter.rooms[socket.id].kurucuAdi = js.oyuncuAdi;//ANDROIDDEN
		io.sockets.adapter.rooms[socket.id].petekData = js.petekData;//ANDROIDDEN
		io.sockets.adapter.rooms[socket.id].kurucuTokenId = js.tokenId;//android device id buraya gelecek
		io.sockets.adapter.rooms[socket.id].kurucuId = socket.id;
		io.sockets.adapter.rooms[socket.id].oyunKurma = true;//BU ODAYA KATILINABILIR
		socket.kurucu = true;
		*/
	});
	
	socket.on("server-oyunaGir",(data)=>
	{
		var js =  JSON.parse(data);
		let odaBulmaDurum = false;
		for(let i = 0;i < Object.keys(io.sockets.adapter.rooms).length;i++)
		{ //toplam oda sayısı 
			let odaBilgisi = Object.keys(io.sockets.adapter.rooms)[i];
			if(odaBilgisi.oyunKurma && odaBilgisi.bosluk == 1)
			{
				//Odada rakip yoksa bu if içerisine girer.
				//2. KULLANICININ ODAYA YOLLADIĞI BİLGİLER
				io.sockets.adapter.rooms[odaBilgisi].bosluk = 0;//yeni birisi bu kişinin odasına katıldıgı ıcın artık yer kalmadı => 0
				odaBulmaDurum = true;
				io.sockets.adapter.rooms[odaBilgisi].katilanAdi = js.oyuncuAdi;
				io.sockets.adapter.rooms[odaBilgisi].katilanId = socket.id;
				io.sockets.adapter.rooms[odaBilgisi].katilanTokenId = js.tokenId; //android device id buraya gelecek
				let katilanAdi = io.sockets.adapter.rooms[odaBilgisi].katilanAdi;
				let katilanId = io.sockets.adapter.rooms[odaBilgisi].katilanId;
				let katilanTokenId = io.sockets.adapter.rooms[odaBilgisi].katilanTokenId;
				
				//ODAYA GÖNDERİLEN BİLGİLER
				socket.to(odaBilgisi).emit("client-odaYeniKisi",{katilanId:katilanId,katilanTokenId:katilanTokenId,katilanAdi:katilanAdi,katilanPuan:0});
				//ODADAN 2. KULLANICIYA YOLLANAN BİLGİLER.
				socket.join(odaBilgisi,() =>
				{//ODAYA KATILMA ISLEMI CALLBACK
				//OYUNA GİRMEK ISTEYEN KULLANICIYA UYGUN ODA BULUNDU VE ODAYA KATILDIGINA DAİR BILGI GONDERME KISMI
					socket.katildigiOda = odaBilgisi;
					let kurucuAdi = io.sockets.adapter.rooms[odaBilgisi].kurucuAdi;
					let petekData = io.sockets.adapter.rooms[odaBilgisi].petekData;
					let kurucuTokenId = io.sockets.adapter.rooms[odaBilgisi].kurucuTokenId;
					let kurucuId = io.sockets.adapter.rooms[odaBilgisi].kurucuId;
					socket.emit("client-oyunBulundu",{kurucuId:kurucuId,kurucuTokenId:kurucuTokenId,kurucuAdi:kurucuAdi,petekData:petekData});
				});
				break;//oyun bulduysa daha dongude durmasına gerek yok donguyu kır
			}
		}
		if(!odaBulmaDurum)
		{
			//MUSAIT ODA VEYA HIC ODA BULUNAMADI
			socket.emit("client-odaYok",{response:"601"});
		}
	});
	
	//BU HARF GONDERME DURUMLARI HER KULLANICININ ATAGI SIRASINDA AKTARILMASI GEREKEN BIR DURUM ISE
	socket.on("server-oyuncuHamle",(data)=>//BU KISIMDA HANGI OYUNCU ATAK YAPTIYSA ANLADIGIM KADARIYLA HARF BILGISI GONDERECEK
	{
		//data ya gonderılmesı gerekenler odaAdi,atakyapan ıd,atak harf
		
	});
	
	socket.on("server-oyunBitti",(data)=>//data.kurucuId
	{
		if(socket.id == data.kurucuId)//OYUNCU KURUCUYSA
		{
			io.sockets.adapter.rooms[socket.id].oyunKurma = false;
			io.sockets.adapter.rooms[socket.id].bosluk = 1;
			socket.kurucu = false;
		}
		else
		{
			socket.leave(data.kurucuId);
			socket.katildigiOda = "";
		}
	});
	
	//socket port bağlantısı kullanıcı tarafından sonlandırıldıysa
	socket.on('disconnect', function () {
	  console.log('Socket '+socket.id+' disconnected.');
	  
	  io.to("client-playerCount",{count:Object.keys(io.sockets.adapter.rooms).length});//ODA SAYISI //ONLINE OYUNCU SAYISI
	  //OYUN BITMEDEN AYRILAN KULLANICI ICIN OZEL DURUM
	  //AYRILAN KISI OYUN KURUCU MU? OYUNA KATILAN KISI MI? YOKSA SADECE GIRISTE BEKLEYEN KİŞİ Mİ? ONU AYIRT ETMEK GEREKIYOR ILK ONCE
		if(typeof socket.katildigiOda !== "undefined" && socket.katildigiOda !== "" && !socket.kurucu)//HERHANGI BIR ODAYA KAYITLI
		{
			socket.to(socket.katildigiOda).emit("client-rakipCikti",{response:"701"});
		}
		
	  
	});

});

/*
emit android tarafından yakalanacak metot demek

emit - client-rakipCikti	- android tarafında oynaactivity'e eklendi
emit - client-odaYok		- android tarafında oynaactivity'e eklendi
emit - client-odaYeniKisi
emit - client-oyunBulundu

on ise android den gönderilecek değer demek
mSocket.emit("mesaj",etMesaj.getText().toString());
android den emit metot gönderirsen, js de on metodu tetiklemiş olursun.
on - server-oyunaGir		- android tarafında oynaactivity'e eklendi
on - server-oyunOlustur		- android tarafında oynaactivity'e eklendi
on - server-oyunBitti
on - server-oyuncuHamle		
on - connection				- android tarafında oynaactivity'e eklendi
on - disconnect				- android tarafında oynaactivity'e eklendi
*/
//var roomId = null;
//var userTokenId1  = null;
//var userTokenId1  = null;
//var userId1 = null;
//var userId2 = null;
//var userName1 = null;
//var userName2 = null;
//var harf = null;
//var userPoint1 = null;
//var userPoint2 = null;
//var petekData = null;

//on getGamerCount
//emit kullanici1Puani
//on kullanici1PuaniResponse
//on kullanici2PuaniResponse
