﻿var app = require('express')();
var server = require('http').createServer(app);
var io = require('socket.io')(server);

app.get('/', function(req, res) {
   res.sendfile('index.html');
});
server.listen(3000, function() {
   console.log('listening on localhost:3000');
});
io.attach(server);
io.on('connection', function(socket)
{
	console.log('Socket '+socket.id+' connected.');
	io.to("client-playerCount",{count:Object.keys(io.sockets.adapter.rooms).length});//ONLINE OYUNCU SAYISI
	//var roomId = null;
	//var userTokenId1  = null;
	//var userTokenId1  = null;
	//var userId1 = null;
	//var userId2 = null;
	//var userName1 = null;
	//var userName2 = null;
	//var harf = null;
	//var userPoint1 = null;
	//var userPoint2 = null;
	//var petekData = null;
	
	io.sockets.adapter.rooms[socket.id].oyunKurma = false;
	io.sockets.adapter.rooms[socket.id].bosluk = 1;//adama katılabilecek kısı sayısı => sadece 1 kisi girebilir

	socket.on("server-oyunOlustur",(data)=>
	{
		io.sockets.adapter.rooms[socket.id].kurucuPuan = 0;
		io.sockets.adapter.rooms[socket.id].kurucuAdi = data.oyuncuAdi;//ANDROIDDEN
		io.sockets.adapter.rooms[socket.id].petekData = data.petekData;//ANDROIDDEN
		io.sockets.adapter.rooms[socket.id].kurucuTokenId = data.tokenId;//ANDROIDDEN
		io.sockets.adapter.rooms[socket.id].kurucuId = socket.id;
		io.sockets.adapter.rooms[socket.id].oyunKurma = true;//BU ODAYA KATILINABILIR
		socket.kurucu = true;
	});
	socket.on("server-oyunaGir",(data)=>
	{
		let odaBulmaDurum = false;
		for(let i = 0;i < Object.keys(io.sockets.adapter.rooms).length;i++)
		{
			let odaBilgisi = Object.keys(io.sockets.adapter.rooms)[i];
			if(odaBilgisi.oyunKurma && odaBilgisi.bosluk == 1)
			{
				io.sockets.adapter.rooms[odaBilgisi].bosluk = 0;//yenı birisi bu kişinin odasına katıldıgı ıcın artık yer kalmadı => 0
				odaBulmaDurum = true;
				io.sockets.adapter.rooms[odaBilgisi].katilanAdi = data.oyuncuAdi;
				io.sockets.adapter.rooms[odaBilgisi].katilanId = socket.id;
				io.sockets.adapter.rooms[odaBilgisi].katilanTokenId = data.tokenId;
				let katilanAdi = io.sockets.adapter.rooms[odaBilgisi].katilanAdi;
				let katilanId = io.sockets.adapter.rooms[odaBilgisi].katilanId;
				let katilanTokenId = io.sockets.adapter.rooms[odaBilgisi].katilanTokenId;
				socket.to(odaBilgisi).emit("client-odaYeniKisi",{katilanId:katilanId,katilanTokenId:katilanTokenId,katilanAdi:katilanAdi,katilanPuan:0});
				socket.join(odaBilgisi,() =>
				{//ODAYA KATILMA ISLEMI CALLBACK
				//OYUNA GİRMEK ISTEYEN KULLANICIYA UYGUN ODA BULUNDU VE ODAYA KATILDIGINA DAİR BILGI GONDERME KISMI
					socket.katildigiOda = odaBilgisi;
					let kurucuAdi = io.sockets.adapter.rooms[odaBilgisi].kurucuAdi;
					let petekData = io.sockets.adapter.rooms[odaBilgisi].petekData;
					let kurucuTokenId = io.sockets.adapter.rooms[odaBilgisi].kurucuTokenId;
					let kurucuId = io.sockets.adapter.rooms[odaBilgisi].kurucuId;
					socket.emit("client-oyunBulundu",{kurucuId:kurucuId,kurucuTokenId:kurucuTokenId,kurucuAdi:kurucuAdi,petekData:petekData});
				});
				break;//oyun bulduysa daha dongude durmasına gerek yok donguyu kır
			}
		}
		if(!odaBulmaDurum)
		{
			//MUSAIT ODA VEYA HIC ODA BULUNAMADI
			socket.emit("client-odaYok",{mesaj:"Müsait oda bulunamadı."});
		}
	});
	
	//BU HARF GONDERME DURUMLARI HER KULLANICININ ATAGI SIRASINDA AKTARILMASI GEREKEN BIR DURUM ISE
	socket.on("server-oyuncuHamle",(data)=>//BU KISIMDA HANGI OYUNCU ATAK YAPTIYSA ANLADIGIM KADARIYLA HARF BILGISI GONDERECEK
	{
		//data ya gonderılmesı gerekenler odaAdi,atakyapan ıd,atak harf
		
	});
	
	socket.on("server-oyunBitti",(data)=>//data.kurucuId
	{
		if(socket.id == data.kurucuId)//OYUNCU KURUCUYSA
		{
			io.sockets.adapter.rooms[socket.id].oyunKurma = false;
			io.sockets.adapter.rooms[socket.id].bosluk = 1;
			socket.kurucu = false;
		}
		else
		{
			socket.leave(data.kurucuId);
			socket.katildigiOda = "";
		}
	});
	
	socket.on('disconnect', function () {
	  console.log('Socket '+socket.id+' disconnected.');
	  io.to("client-playerCount",{count:Object.keys(io.sockets.adapter.rooms).length});//ONLINE OYUNCU SAYISI
	  //OYUN BITMEDEN AYRILAN KULLANICI ICIN OZEL DURUM
	  //AYRILAN KISI OYUN KURUCU MU? OYUNA KATILAN KISI MI? YOKSA SADECE GIRISTE BEKLEYEN KİŞİ Mİ? ONU AYIRT ETMEK GEREKIYOR ILK ONCE
		if(typeof socket.katildigiOda !== "undefined" && socket.katildigiOda !== "" && !socket.kurucu)//HERHANGI BIR ODAYA KAYITLI
		{
			socket.to(socket.katildigiOda).emit("client-rakipCikti");
		}
		
	  
	});

});

