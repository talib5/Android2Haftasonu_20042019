var app = require('express')();
var server = require('http').createServer(app);
var io = require('socket.io')(server);

server.listen(4002);
var oyuncuSayisi = 0; 

io.on('connection',function(socket){
	
	console.log("Client connected");
	var roomId = null;
	var userTokenId1  = null;
	var userTokenId1  = null;
	var userId1 = null;
	var userId2 = null;
	var userName1 = null;
	var userName2 = null;
	var harf = null;
	var userPoint1 = null;
	var userPoint2 = null;
	var petekData = null;

	oyuncuSayisi++;

	
	io.emit('getGamerCount',oyuncuSayisi);
	
	socket.on('mesaj',function(data){ // androidden gelen de�eri yakala
		console.log(data); //edittextden gelen de�eri yazd�r
		io.emit('mesajAl',data); // sunucudan android'e de�er g�nder 
	});

	socket.on('kullanici1Puani',function(data){ // androidden gelen de�eri yakala
		console.log(data); //edittextden gelen de�eri yazd�r
		io.emit('kullanici1PuaniResponse',data); // sunucudan android'e de�er g�nder 
	});
	socket.on('kullanici2Puani',function(data){ // androidden gelen de�eri yakala
		console.log(data); //edittextden gelen de�eri yazd�r
		io.emit('kullanici2PuaniResponse',data); // sunucudan android'e de�er g�nder 
	});
	
});